using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace SchoolAPI.Models
{
    public class Course
    {
    [Key]
    public int Id { get; set; }
    public string? Name { get; set; }
    public string? Description { get; set; }
    public int TeacherId { get; set; }
    [JsonIgnore]
    public Teacher? Teacher { get; set; }
    public string? Schedule { get; set; }
    public string? Duration { get; set; }
    public int Capacity { get; set; }
    [JsonIgnore]
    public ICollection<Enrollment>? Enrollments { get; set; }
    }
}