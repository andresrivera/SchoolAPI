using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace SchoolAPI.Models
{
    public class Student
    {
        [Key]
        public int Id { get; set; }
        public string? Names { get; set; }
        public DateTime BirthDate { get; set; }
        public string? Address { get; set; }
        public string? Email { get; set; }
        [JsonIgnore]
        public ICollection<Enrollment>? Enrollments { get; set; }
    }
}