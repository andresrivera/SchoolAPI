using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace SchoolAPI.Models
{
    public class Enrollment
    {
    [Key]
 
       public int Id { get; set; }
    public DateTime Date { get; set; }
    public int StudentId { get; set; }
    [JsonIgnore]
    public Student? Student { get; set; }
    public int CourseId { get; set; }
    [JsonIgnore]
    public Course? Course { get; set; }
    public string? Status { get; set; } 
    }
}