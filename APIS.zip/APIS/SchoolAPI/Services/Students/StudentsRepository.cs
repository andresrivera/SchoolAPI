// Repositories/StudentRepository.cs
using SchoolAPI.Data;
using SchoolAPI.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SchoolAPI.Repositories
{
    public class StudentRepository : IStudentRepository
    {
        private readonly SchoolBaseContext _context;

        public StudentRepository(SchoolBaseContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Student>> GetAllStudentsAsync()
        {
            return await _context.Students.ToListAsync();
        }

        public async Task<Student> GetStudentById(int id)
        {
            return await _context.Students.FindAsync(id);
        }

        public async Task<Student> AddStudent(Student medico)
        {
            _context.Students.Add(medico);
            await _context.SaveChangesAsync();
            return medico;
        }

        public async Task<Student> UpdateStudent(Student medico)
        {
            _context.Entry(medico).State = EntityState.Modified;
            await _context.SaveChangesAsync();
            return medico;
        }

        public Task<Student> RestoreStudent(Student Student)
        {
            throw new NotImplementedException();
        }

        public Task<bool> DeleteStudent(int id)
        {
            throw new NotImplementedException();
        }
    }
}