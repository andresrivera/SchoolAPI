// Repositories/IStudentRepository.cs
using SchoolAPI.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SchoolAPI.Repositories
{
    public interface IStudentRepository
    {
        Task<IEnumerable<Student>> GetAllStudentsAsync();
        Task<Student> GetStudentById(int id);
        Task<Student> AddStudent(Student Student);
        Task<Student> UpdateStudent(Student Student);
        Task<Student> RestoreStudent(Student Student);
        Task<bool> DeleteStudent(int id);
       
    }
}