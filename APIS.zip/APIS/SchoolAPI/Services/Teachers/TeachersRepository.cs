using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using SchoolAPI.Data;
using SchoolAPI.Dto;
using SchoolAPI.Models;

namespace SchoolAPI.Services.Teachers
{
    public class TeachersRepository : ITeachersRepository
    {
        private readonly SchoolBaseContext _context;
        public TeachersRepository(SchoolBaseContext context)
        {
            _context = context;
        }
        //crear
        public async Task<IEnumerable<Teacher>> GetAllTeachersAsync()
        {
            return await _context.Teachers.ToListAsync();
        }

        public async Task<Teacher> GetTeacherById(int id)
        {
            return await _context.Teachers.FindAsync(id);
        }

        public async Task<Teacher> AddTeacher(Teacher medico)
        {
            _context.Teachers.Add(medico);
            await _context.SaveChangesAsync();
            return medico;
        }

        public async Task<Teacher> UpdateTeacher(Teacher medico)
        {
            _context.Entry(medico).State = EntityState.Modified;
            await _context.SaveChangesAsync();
            return medico;
        }
    }
}