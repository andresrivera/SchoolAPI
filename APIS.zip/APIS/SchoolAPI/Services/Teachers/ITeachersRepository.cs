// Repositories/ITeacherRepository.cs
using SchoolAPI.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SchoolAPI.Services
{
    public interface ITeachersRepository
    {
        Task<IEnumerable<Teacher>> GetAllTeachersAsync();
        Task<Teacher> GetTeacherById(int id);
        Task<Teacher> AddTeacher(Teacher Teacher);
        Task<Teacher> UpdateTeacher(Teacher Teacher);

       
    }
}