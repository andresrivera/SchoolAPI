namespace SchoolAPI.Dto
{
    public class StudentDto
    {
        public int Id { get; set; }
        public string? Names { get; set; }
        public DateTime BirthDate { get; set; }
        public string? Address { get; set; }
        public string? Email { get; set; }
    }
}