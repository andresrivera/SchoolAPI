namespace SchoolAPI.Dto
{
    public class CourseDto
    {
        public int Id { get; set; }
        public string? Name { get; set; }
        public string? Description { get; set; }
        public int TeacherId { get; set; }
        public string? Schedule { get; set; }
        public string? Duration { get; set; }
        public int Capacity { get; set; }
    }
}

