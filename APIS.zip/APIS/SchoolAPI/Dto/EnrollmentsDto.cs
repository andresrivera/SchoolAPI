namespace SchoolAPI.Dto
{
    public class EnrollmentDto
    {
        public int Id { get; set; }
        public DateTime Date { get; set; }
        public int StudentId { get; set; }
        public int CourseId { get; set; }
        public string? Status { get; set; }
    }
}