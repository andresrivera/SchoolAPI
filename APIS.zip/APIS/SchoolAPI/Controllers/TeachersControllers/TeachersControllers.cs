using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

using SchoolAPI.Models;
using SchoolAPI.Services;

namespace SchoolAPI.Data;
[ApiController]
[Route("api/[controller]")]
public class TeachersController : ControllerBase
{
    private readonly ITeachersRepository _teacherService;

    public TeachersController(ITeachersRepository teacherService)
    {
        _teacherService = teacherService;
    }

 
        [HttpGet]
        [Route("api/Teachers")]
    public  ActionResult<IEnumerable<Teacher>> GetTeachers()
    {
        var teachers =  _teacherService.GetAllTeachersAsync();
        return Ok(teachers);
    }

    [HttpGet("{id}")]
    //[Route("api/Teachers/{id}")]
    public async Task<ActionResult<Teacher>> GetTeacherById(int id)
    {
        var Teacher = await _teacherService.GetTeacherById(id);
        if (Teacher == null)
        {
            return NotFound();
        }
        return Ok(Teacher);
    }

      
    }
